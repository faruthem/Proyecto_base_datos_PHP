<?php
//Elije una contraseñ$
$password_plana = '123456';

//Genera el HASH
$hash_seguro = password_hash($password_plana, PASSWORD_BCRYPT);

echo "Tu contraseña es: " . $password_plana . "<br>";
echo "Tu HASH (guarda esto):<br>";
echo $hash_seguro;

//Ejemplo de salida: $2y$10$T8.G5L.F0j/jY.fQh8UfIu9yS.L/qG.q3jO.1e.4p/Z.C/w.K
