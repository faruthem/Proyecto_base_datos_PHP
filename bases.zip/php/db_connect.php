<?php
/*
 * CONEXIÓN A LA BASE DE DATOS
 * El estándar moderno es PDO (PHP Data Objects).
 */

// ===== INICIO: CONFIGURACIÓN DE SESIÓN =====
// 1. Tiempo de vida de la sesión en segundos (ej. 1 hora = 3600 segundos)
// Si el usuario está inactivo por este tiempo, la sesión se borra del servidor.
ini_set('session.gc_maxlifetime', 3600);
// 2. Tiempo de vida de la cookie de sesión
// Esto le dice al navegador cuándo debe olvidar la cookie.
// 0 = se borra al cerrar el navegador.
// 3600 = la cookie dura 1 hora, incluso si cierra y abre el navegador.
session_set_cookie_params(3600); 
// ===== FIN: CONFIGURACIÓN DE SESIÓN =====
// ¡Importante! Iniciar la sesión DESPUÉS de configurar los parámetros.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = '127.0.0.1'; // 'localhost'
$db   = 'sistema_escolar'; // El nombre que pusimos en el Paso 2
$user = 'root'; // Usuario por defecto de XAMPP
$pass = '';     // Contraseña por defecto de XAMPP (vacía)
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// ¡Importante! Iniciar la sesión en CADA script que la necesite.
// Lo ponemos aquí para asegurarnos de que siempre se inicie.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}